flask_angular
=============

Flask ReST service shows directory and tar file contents with options regex.
This is for class demo purposes only. Don't run this on a publicly accessible server, unless
you want the entire world to see the contents of your hard drive. 
