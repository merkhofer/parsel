var angular_file_tar_module = angular.module("angularFileTar", ["ngResource","angularBootstrapNavTree"]);

var flask_ftm_server = "http://127.0.0.1:7000/";

angular_file_tar_module.factory("AngularFTMService", function($resource){
    return {
        // Don't use JSONP: deserialization problems.
        //content_list: $resource(flask_ftm_server + "/source/CTS/container/:container_id/list/?callback=placeholder", 
        content_list: $resource("http://127.0.0.1:5000/source/CTS/container/:container_id/list/ ", 
             //{format:'json'},
             {container_id: '@container_id'},
             {query: {/*cache:true,*/ method:'GET', params:{}, isArray:false}}
        ),
        contents: $resource("http://127.0.0.1:5000/source/CTS/container/:container_id/ ",
             //{format:'json'},
             {container_id: '@container_id'},
             {query: {/*cache:true,*/ method:'GET', params:{}, isArray:false}}
        ),
        file_by_name: $resource("http://127.0.0.1:5000/source/CTS/container/:container_id/file/:file_path_name/ ", 
             //{format:'json'},
             {container_id: '@container_id', file_path_name: '@file_path_name'},
             {query: {/*cache:true,*/ method:'GET', params:{}, isArray:false}}
        ),
        file_by_url: $resource("http://127.0.0.1:5000/source/CTS/container/:container_id/:file_url/ ",
             //{format:'json'},
             {container_id: '@container_id', file_url: '@file_url'},
             {query: {/*cache:true,*/ method:'GET', params:{}, isArray:false}}
        )
       }
    });


var ctsApiController = function($scope,$http,CTSAPI) {
    $http.defaults.useXDomain = true; // Necessary for external services.

    $scope.ctsScope = {container_id:null, file_path_name:null, file_url:null,
        content_list:null, by_name_results:null, by_url_results:null,
        dir_structure:[] };


    var api_failed = function(failure) {
        console.log("CTSAPI call failed!: " + failure.toSource());
        }

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    // Calls to resources
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    $scope.ctsScope.get_content_list = function() {
        CTSAPI["content_list"].query({container_id:$scope.ctsScope.container_id}, 
            function(data) {
                // Success of some kind
                $scope.ctsScope.content_list = data;
                $scope.ctsScope.dir_structure = data.results.dir_structure;
                $scope.ctsScope.content_list.all_files = [];
                var key = null;
                for(key in $scope.ctsScope.content_list.results.flist) {
                    $scope.ctsScope.content_list.all_files.push.apply($scope.ctsScope.content_list.all_files,$scope.ctsScope.content_list.results.flist[key]);
                    }
                },
            function(failure) {
                // failure
                $scope.ctsScope.content_list = null;
                $scope.ctsScope.dir_structure = [];
                if(failure.status == 404) {
                    console.log("CTS container list not found:" + failure.toSource());
                    }
                else {
                    console.log("CTS container list call failed!:" + failure.toSource());
                    }
                });
        }

    $scope.ctsScope.get_contents = function() {
        $scope.ctsScope.contents = CTSAPI["contents"].query({container_id:$scope.ctsScope.container_id});
        }

    $scope.ctsScope.get_file_by_name = function() {
        $scope.ctsScope.by_name_results = CTSAPI["file_by_name"].query({container_id:$scope.ctsScope.container_id,file_path_name:$scope.ctsScope.file_path_name});
        }

    $scope.ctsScope.get_file_by_url = function() {
        $scope.ctsScope.by_url_results = CTSAPI["file_by_url"].query({container_id:$scope.ctsScope.container_id,file_url:$scope.ctsScope.file_url});
        }
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    // Watch events
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    /*$scope.$watch('ctsScope.content_list', function(newVal) {
        alert("New Data", newVal);
        $scope.x = newVal;
        }); */

    };

angular_file_tar_module.directive("containerDirective", function () {
    return {
        restrict: "EA",
        link: function (scope, element, attrs) {
            scope.$watch(attrs.ngModel, function (v) {
                console.log('value changed, new value is: ' + v);
                });
            },
        //transclude: true,
        //template: 'Here: <table> \
        //               <tr ng-repeat="c in scope.ctsScope.content_list.results.flist"> \
        //                   <td ng-bind="c">Loop</td> \
        //               </tr> \
        //           </table> end here <div ng-transclude></div>'
        }
    });

